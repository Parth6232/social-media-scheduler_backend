require("dotenv").config();

// FIX: Render ke network mein IPv6 route available nahi hai, jiski wajah se
// Gmail SMTP (smtp.gmail.com) jaise IPv6-returning hosts se connect karte waqt
// "ENETUNREACH" error aata tha. Ye line Node ko DNS lookup mein IPv4 address
// ko priority dene ke liye force karti hai (Node 18+ required).
const dns = require("dns");
dns.setDefaultResultOrder("ipv4first");

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const authRoutes = require("./routes/authRoutes");
const youtubeAuthRoutes = require("./routes/youtubeAuthRoutes");
const postRoutes = require("./routes/postRoutes");
const { startScheduler } = require("./services/scheduler");
const facebookAuthRoutes = require("./routes/facebookAuthRoutes");
const accountRoutes = require("./routes/accountRoutes");
const aiRoutes = require("./routes/aiRoutes");
const mediaRoutes = require("./routes/mediaRoutes");


const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));


app.get("/", (req, res) => {
  res.json({
    message: "Social Media Scheduler API is running"
  });
});
app.use('/api/auth', authRoutes);
app.use('/api/auth/youtube', youtubeAuthRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/auth/facebook', facebookAuthRoutes);
app.use('/api/accounts', accountRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/media', mediaRoutes);
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.message);
  res.status(err.status || 500).json({
    message: err.message || 'Something went wrong on server'
  });
});
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected successfully");
    startScheduler(); // Scheduler ko start karna

    app.listen(process.env.PORT, () => {
      console.log(`Server running on http://localhost:${process.env.PORT}`);
    });
  })
  .catch((error) => {
    console.error("MongoDB connection failed:", error.message);
  });